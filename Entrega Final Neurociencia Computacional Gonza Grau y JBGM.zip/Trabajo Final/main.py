from neuron_models.lif import LIF_model, test_lif
from neuron_models.adex import test_adex, Adex_model
from neuron_models.hodgkin_huxley import test_hyh
from neuron_models.utils import firing_rate
from time import time
import  numpy as np

def main():
    ...
    # test_adex()
    test_lif()


    test_hyh()
    

if __name__ == '__main__':
    main()

    